import { createContext, useContext, useState, type ReactNode } from "react";

export type Perfil = "Usuário" | "Revisor" | "Administrador";
export type Usuario = { nome: string; email: string; perfil: Perfil };

export type StatusEmpresa = "Ativa" | "Inativa" | "Em verificação";
export type Empresa = {
  id: number;
  razaoSocial: string;
  nomeFantasia: string;
  cnpj: string;
  segmento: string;
  porte: string;
  cidade: string;
  uf: string;
  email: string;
  telefone: string;
  cnae: string;
  status: StatusEmpresa;
  criadoEm: string;
};

export type StatusLead = "Em análise" | "Qualificado" | "Rejeitado";
export type Lead = {
  id: number;
  pessoa: string;
  email: string;
  cargo: string;
  empresaId: number;
  status: StatusLead;
  confianca: number;
  origem: string;
  criadoEm: string;
  historico: { data: string; autor: string; acao: string; comentario?: string }[];
};

export const CNAES: { codigo: string; descricao: string }[] = [
  { codigo: "6201-5/01", descricao: "Desenvolvimento de software sob encomenda" },
  { codigo: "6202-3/00", descricao: "Desenvolvimento de software customizável" },
  { codigo: "4930-2/02", descricao: "Transporte rodoviário de carga" },
  { codigo: "1091-1/02", descricao: "Fabricação de produtos de panificação" },
  { codigo: "7020-4/00", descricao: "Consultoria em gestão empresarial" },
  { codigo: "8630-5/03", descricao: "Atividade médica ambulatorial" },
  { codigo: "2512-8/00", descricao: "Fabricação de esquadrias de metal" },
];

const empresasIniciais: Empresa[] = [
  { id: 1, razaoSocial: "Vértice Sistemas Ltda.", nomeFantasia: "Vértice", cnpj: "12.345.678/0001-90", segmento: "Tecnologia", porte: "Médio", cidade: "Campinas", uf: "SP", email: "contato@vertice.exemplo", telefone: "(19) 3201-4400", cnae: "6201-5/01", status: "Ativa", criadoEm: "2026-09-14" },
  { id: 2, razaoSocial: "Transportes Serra Azul S.A.", nomeFantasia: "Serra Azul Log", cnpj: "23.456.789/0001-01", segmento: "Logística", porte: "Grande", cidade: "Curitiba", uf: "PR", email: "comercial@serraazul.exemplo", telefone: "(41) 3344-1200", cnae: "4930-2/02", status: "Ativa", criadoEm: "2026-08-02" },
  { id: 3, razaoSocial: "Padaria Grão Dourado Eireli", nomeFantasia: "Grão Dourado", cnpj: "34.567.890/0001-12", segmento: "Alimentos", porte: "Pequeno", cidade: "Belo Horizonte", uf: "MG", email: "adm@graodourado.exemplo", telefone: "(31) 3555-0987", cnae: "1091-1/02", status: "Em verificação", criadoEm: "2026-10-21" },
  { id: 4, razaoSocial: "Norte Consultoria Empresarial Ltda.", nomeFantasia: "Norte Consult", cnpj: "45.678.901/0001-23", segmento: "Serviços", porte: "Pequeno", cidade: "Recife", uf: "PE", email: "ola@norteconsult.exemplo", telefone: "(81) 3021-7788", cnae: "7020-4/00", status: "Ativa", criadoEm: "2026-07-11" },
  { id: 5, razaoSocial: "Clínica Integrada Bem Viver Ltda.", nomeFantasia: "Bem Viver", cnpj: "56.789.012/0001-34", segmento: "Saúde", porte: "Médio", cidade: "Porto Alegre", uf: "RS", email: "gestao@bemviver.exemplo", telefone: "(51) 3233-4410", cnae: "8630-5/03", status: "Inativa", criadoEm: "2026-03-30" },
  { id: 6, razaoSocial: "Metalúrgica Fortaleza Ltda.", nomeFantasia: "MetalFort", cnpj: "67.890.123/0001-45", segmento: "Indústria", porte: "Grande", cidade: "Joinville", uf: "SC", email: "vendas@metalfort.exemplo", telefone: "(47) 3433-9001", cnae: "2512-8/00", status: "Ativa", criadoEm: "2026-05-19" },
  { id: 7, razaoSocial: "Códice Software Ltda.", nomeFantasia: "Códice", cnpj: "78.901.234/0001-56", segmento: "Tecnologia", porte: "Pequeno", cidade: "Florianópolis", uf: "SC", email: "time@codice.exemplo", telefone: "(48) 3025-6600", cnae: "6202-3/00", status: "Em verificação", criadoEm: "2026-10-29" },
];

const h = (data: string, acao: string, autor = "Sistema") => [{ data, autor, acao }];
const leadsIniciais: Lead[] = [
  { id: 101, pessoa: "Mariana Teixeira", email: "mariana.t@vertice.exemplo", cargo: "Diretora de TI", empresaId: 1, status: "Em análise", confianca: 82, origem: "Importação CSV", criadoEm: "2026-10-30", historico: h("2026-10-30", "Lead criado") },
  { id: 102, pessoa: "Ricardo Almeida", email: "ricardo@serraazul.exemplo", cargo: "Gerente de Operações", empresaId: 2, status: "Qualificado", confianca: 91, origem: "Cadastro manual", criadoEm: "2026-10-12", historico: [...h("2026-10-12", "Lead criado"), { data: "2026-10-15", autor: "Paula Rezende", acao: "Qualificado", comentario: "Contato confirmado por telefone." }] },
  { id: 103, pessoa: "Fernanda Lopes", email: "fernanda@graodourado.exemplo", cargo: "Sócia-administradora", empresaId: 3, status: "Em análise", confianca: 54, origem: "Cadastro manual", criadoEm: "2026-10-28", historico: h("2026-10-28", "Lead criado") },
  { id: 104, pessoa: "Thiago Nunes", email: "thiago.n@norteconsult.exemplo", cargo: "Consultor Sênior", empresaId: 4, status: "Rejeitado", confianca: 31, origem: "Importação CSV", criadoEm: "2026-09-20", historico: [...h("2026-09-20", "Lead criado"), { data: "2026-09-22", autor: "Paula Rezende", acao: "Rejeitado", comentario: "Sem poder de decisão de compra." }] },
  { id: 105, pessoa: "Camila Rocha", email: "camila@metalfort.exemplo", cargo: "Coordenadora de Compras", empresaId: 6, status: "Em análise", confianca: 76, origem: "Importação CSV", criadoEm: "2026-11-01", historico: h("2026-11-01", "Lead criado") },
  { id: 106, pessoa: "André Pacheco", email: "andre@codice.exemplo", cargo: "CTO", empresaId: 7, status: "Em análise", confianca: 68, origem: "Cadastro manual", criadoEm: "2026-11-02", historico: h("2026-11-02", "Lead criado") },
  { id: 107, pessoa: "Luciana Barros", email: "luciana@bemviver.exemplo", cargo: "Gerente Administrativa", empresaId: 5, status: "Qualificado", confianca: 87, origem: "Cadastro manual", criadoEm: "2026-08-08", historico: [...h("2026-08-08", "Lead criado"), { data: "2026-08-10", autor: "Paula Rezende", acao: "Qualificado" }] },
  { id: 108, pessoa: "Eduardo Saraiva", email: "eduardo@vertice.exemplo", cargo: "Analista de Sistemas", empresaId: 1, status: "Em análise", confianca: 42, origem: "Importação CSV", criadoEm: "2026-10-31", historico: h("2026-10-31", "Lead criado") },
];

type Store = {
  usuario: Usuario | null;
  entrar: (u: Usuario) => void;
  sair: () => void;
  empresas: Empresa[];
  adicionarEmpresa: (e: Omit<Empresa, "id" | "criadoEm" | "status">) => Empresa;
  leads: Lead[];
  revisarLead: (id: number, status: StatusLead, comentario: string) => void;
};

const Ctx = createContext<Store | null>(null);

export function StoreProvider({ children }: { children: ReactNode }) {
  const [usuario, setUsuario] = useState<Usuario | null>(null);
  const [empresas, setEmpresas] = useState(empresasIniciais);
  const [leads, setLeads] = useState(leadsIniciais);

  const store: Store = {
    usuario,
    entrar: setUsuario,
    sair: () => setUsuario(null),
    empresas,
    adicionarEmpresa: (e) => {
      const nova: Empresa = { ...e, id: Math.max(...empresas.map((x) => x.id)) + 1, status: "Em verificação", criadoEm: new Date().toISOString().slice(0, 10) };
      setEmpresas((l) => [nova, ...l]);
      return nova;
    },
    leads,
    revisarLead: (id, status, comentario) =>
      setLeads((l) =>
        l.map((x) =>
          x.id === id
            ? { ...x, status, historico: [...x.historico, { data: new Date().toISOString().slice(0, 10), autor: usuario?.nome ?? "—", acao: status === "Em análise" ? "Mantido em análise" : status, comentario: comentario || undefined }] }
            : x,
        ),
      ),
  };
  return <Ctx.Provider value={store}>{children}</Ctx.Provider>;
}

export function useStore() {
  const s = useContext(Ctx);
  if (!s) throw new Error("StoreProvider ausente");
  return s;
}

export const formatarData = (iso: string) => iso.split("-").reverse().join("/");

export function validarCnpj(v: string) {
  return /^\d{2}\.\d{3}\.\d{3}\/\d{4}-\d{2}$/.test(v);
}
export function mascaraCnpj(v: string) {
  const d = v.replace(/\D/g, "").slice(0, 14);
  return d
    .replace(/^(\d{2})(\d)/, "$1.$2")
    .replace(/^(\d{2})\.(\d{3})(\d)/, "$1.$2.$3")
    .replace(/\.(\d{3})(\d)/, ".$1/$2")
    .replace(/(\d{4})(\d)/, "$1-$2");
}
export function mascaraTelefone(v: string) {
  const d = v.replace(/\D/g, "").slice(0, 11);
  if (d.length <= 10) return d.replace(/^(\d{2})(\d)/, "($1) $2").replace(/(\d{4})(\d)/, "$1-$2");
  return d.replace(/^(\d{2})(\d)/, "($1) $2").replace(/(\d{5})(\d)/, "$1-$2");
}
