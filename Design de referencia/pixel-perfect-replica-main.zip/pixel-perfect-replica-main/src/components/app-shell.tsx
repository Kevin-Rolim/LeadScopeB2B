import { Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState, type ReactNode } from "react";
import { Building2, LayoutGrid, LogOut, Menu, Target, X } from "lucide-react";
import { useStore } from "@/lib/store";
import { cn } from "@/lib/utils";

export function Logo({ inverted }: { inverted?: boolean }) {
  return (
    <div className="flex items-center gap-2">
      <div className={cn("relative flex size-7 items-center justify-center rounded-md border", inverted ? "border-sidebar-border bg-sidebar-accent" : "border-primary bg-primary")}>
        <span className="size-2.5 rounded-full border-2 border-primary-foreground" />
        <span className="absolute right-1 top-1 size-1.5 rounded-full bg-signal" />
      </div>
      <span className={cn("text-[15px] font-semibold tracking-tight", inverted ? "text-sidebar-foreground" : "text-foreground")}>
        LeadScope<span className="font-mono text-xs font-medium text-signal">B2B</span>
      </span>
    </div>
  );
}

const nav = [
  { to: "/inicio", label: "Início", icon: LayoutGrid },
  { to: "/empresas", label: "Empresas", icon: Building2 },
  { to: "/leads", label: "Leads", icon: Target },
] as const;

export function AppShell({ children }: { children: ReactNode }) {
  const { usuario, sair } = useStore();
  const navigate = useNavigate();
  const [aberto, setAberto] = useState(false);

  useEffect(() => {
    if (!usuario) navigate({ to: "/" });
  }, [usuario, navigate]);
  if (!usuario) return null;

  const iniciais = usuario.nome.split(" ").map((p) => p[0]).slice(0, 2).join("");

  const sidebar = (
    <div className="flex h-full flex-col bg-sidebar text-sidebar-foreground">
      <div className="flex h-14 items-center justify-between border-b border-sidebar-border px-4">
        <Logo inverted />
        <button className="lg:hidden text-sidebar-muted" onClick={() => setAberto(false)} aria-label="Fechar menu">
          <X className="size-5" />
        </button>
      </div>
      <nav className="flex-1 space-y-0.5 p-2">
        <p className="px-2.5 pb-1 pt-3 text-[10px] font-semibold uppercase tracking-widest text-sidebar-muted">Operação</p>
        {nav.map((n) => (
          <Link
            key={n.to}
            to={n.to}
            onClick={() => setAberto(false)}
            className="flex items-center gap-2.5 rounded-md border-l-2 border-transparent px-2.5 py-2 text-sm text-sidebar-muted hover:bg-sidebar-accent hover:text-sidebar-foreground"
            activeProps={{ className: "!border-signal bg-sidebar-accent !text-sidebar-foreground font-medium" }}
          >
            <n.icon className="size-4" />
            {n.label}
          </Link>
        ))}
      </nav>
      <div className="border-t border-sidebar-border p-3">
        <div className="flex items-center gap-2.5">
          <div className="flex size-8 items-center justify-center rounded-md bg-sidebar-accent font-mono text-xs font-semibold">{iniciais}</div>
          <div className="min-w-0 flex-1">
            <p className="truncate text-sm font-medium">{usuario.nome}</p>
            <p className="truncate text-xs text-sidebar-muted">{usuario.perfil}</p>
          </div>
          <button
            onClick={() => {
              sair();
              navigate({ to: "/" });
            }}
            className="rounded-sm p-1.5 text-sidebar-muted hover:bg-sidebar-accent hover:text-sidebar-foreground"
            aria-label="Sair"
            title="Sair"
          >
            <LogOut className="size-4" />
          </button>
        </div>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen lg:pl-60">
      <aside className="fixed inset-y-0 left-0 z-30 hidden w-60 lg:block">{sidebar}</aside>
      {aberto && (
        <div className="fixed inset-0 z-40 lg:hidden">
          <div className="absolute inset-0 bg-foreground/40" onClick={() => setAberto(false)} />
          <aside className="relative h-full w-64 animate-in slide-in-from-left duration-200">{sidebar}</aside>
        </div>
      )}
      <header className="sticky top-0 z-20 flex h-14 items-center gap-3 border-b bg-card px-4 lg:hidden">
        <button onClick={() => setAberto(true)} aria-label="Abrir menu" className="rounded-sm p-1 hover:bg-muted">
          <Menu className="size-5" />
        </button>
        <Logo />
      </header>
      <main className="mx-auto max-w-[1280px] px-4 py-6 sm:px-6 lg:px-8">{children}</main>
    </div>
  );
}
