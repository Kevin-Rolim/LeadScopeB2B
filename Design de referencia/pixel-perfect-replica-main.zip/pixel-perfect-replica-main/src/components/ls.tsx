import { useEffect, type ButtonHTMLAttributes, type InputHTMLAttributes, type ReactNode, type SelectHTMLAttributes } from "react";
import { Loader2, X } from "lucide-react";
import { cn } from "@/lib/utils";

/* Button */
type BtnVariant = "primary" | "secondary" | "ghost" | "danger" | "success";
const btnVariants: Record<BtnVariant, string> = {
  primary: "bg-primary text-primary-foreground hover:bg-primary/90 border border-primary",
  secondary: "bg-card text-foreground border border-input hover:bg-muted",
  ghost: "text-foreground hover:bg-muted border border-transparent",
  danger: "bg-destructive text-destructive-foreground border border-destructive hover:bg-destructive/90",
  success: "bg-success text-primary-foreground border border-success hover:bg-success/90",
};
export function Button({ variant = "primary", size = "md", loading, className, children, disabled, ...p }: ButtonHTMLAttributes<HTMLButtonElement> & { variant?: BtnVariant; size?: "sm" | "md"; loading?: boolean }) {
  return (
    <button
      {...p}
      disabled={disabled || loading}
      className={cn(
        "inline-flex items-center justify-center gap-1.5 rounded-md font-medium transition-colors disabled:cursor-not-allowed disabled:opacity-60 whitespace-nowrap",
        size === "md" ? "h-9 px-3.5 text-sm" : "h-7 px-2.5 text-xs",
        btnVariants[variant],
        className,
      )}
    >
      {loading && <Loader2 className="size-4 animate-spin" />}
      {children}
    </button>
  );
}

/* Field */
export function Field({ label, error, hint, required, children, className }: { label: string; error?: string; hint?: string; required?: boolean; children: ReactNode; className?: string }) {
  return (
    <label className={cn("block", className)}>
      <span className="mb-1 block text-xs font-medium text-foreground">
        {label}
        {required && <span className="ml-0.5 text-destructive">*</span>}
      </span>
      {children}
      {error ? <span className="mt-1 block text-xs text-destructive">{error}</span> : hint ? <span className="mt-1 block text-xs text-muted-foreground">{hint}</span> : null}
    </label>
  );
}

const inputBase = "h-9 w-full rounded-md border bg-card px-2.5 text-sm text-foreground placeholder:text-muted-foreground/70 focus:outline-none focus:ring-2 focus:ring-ring/25 focus:border-ring";
export function Input({ invalid, className, ...p }: InputHTMLAttributes<HTMLInputElement> & { invalid?: boolean }) {
  return <input {...p} aria-invalid={invalid || undefined} className={cn(inputBase, invalid ? "border-destructive" : "border-input", className)} />;
}
export function Select({ invalid, className, children, ...p }: SelectHTMLAttributes<HTMLSelectElement> & { invalid?: boolean }) {
  return (
    <select {...p} aria-invalid={invalid || undefined} className={cn(inputBase, "pr-7", invalid ? "border-destructive" : "border-input", className)}>
      {children}
    </select>
  );
}
export function Textarea({ className, ...p }: React.TextareaHTMLAttributes<HTMLTextAreaElement>) {
  return <textarea {...p} className={cn(inputBase, "h-auto min-h-20 border-input py-2", className)} />;
}

/* Badge */
type Tone = "neutral" | "success" | "warning" | "danger" | "info";
const tones: Record<Tone, string> = {
  neutral: "bg-muted text-muted-foreground border-border",
  success: "bg-success-soft text-success border-success/25",
  warning: "bg-warning-soft text-warning border-warning/30",
  danger: "bg-danger-soft text-destructive border-destructive/25",
  info: "bg-info-soft text-accent-foreground border-primary/20",
};
export function Badge({ tone = "neutral", children }: { tone?: Tone; children: ReactNode }) {
  return (
    <span className={cn("inline-flex items-center gap-1 rounded-sm border px-1.5 py-0.5 text-xs font-medium", tones[tone])}>
      <span className="size-1.5 rounded-full bg-current" />
      {children}
    </span>
  );
}
export const toneStatus = (s: string): Tone =>
  ({ Ativa: "success", Qualificado: "success", "Em análise": "warning", "Em verificação": "info", Inativa: "neutral", Rejeitado: "danger" } as Record<string, Tone>)[s] ?? "neutral";

/* Confidence */
export function Confianca({ valor }: { valor: number }) {
  const cor = valor >= 75 ? "bg-success" : valor >= 50 ? "bg-warning" : "bg-destructive";
  const nivel = valor >= 75 ? "Alta" : valor >= 50 ? "Média" : "Baixa";
  return (
    <div className="flex items-center gap-2" title={`Confiança ${nivel}`}>
      <div className="h-1.5 w-16 overflow-hidden rounded-sm bg-muted">
        <div className={cn("h-full", cor)} style={{ width: `${valor}%` }} />
      </div>
      <span className="tabular font-mono text-xs text-muted-foreground">{valor}%</span>
    </div>
  );
}

/* Overlay: Modal and side Panel */
function useEsc(open: boolean, onClose: () => void) {
  useEffect(() => {
    if (!open) return;
    const f = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", f);
    document.body.style.overflow = "hidden";
    return () => {
      window.removeEventListener("keydown", f);
      document.body.style.overflow = "";
    };
  }, [open, onClose]);
}

export function Panel({ open, onClose, title, subtitle, children, footer, width = "max-w-xl" }: { open: boolean; onClose: () => void; title: string; subtitle?: string; children: ReactNode; footer?: ReactNode; width?: string }) {
  useEsc(open, onClose);
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-40 flex justify-end">
      <div className="absolute inset-0 bg-foreground/30 animate-in fade-in" onClick={onClose} />
      <aside role="dialog" aria-modal="true" aria-label={title} className={cn("relative flex h-full w-full flex-col border-l bg-card animate-in slide-in-from-right duration-200", width)}>
        <header className="flex items-start justify-between border-b px-5 py-4">
          <div>
            <h2 className="text-base font-semibold">{title}</h2>
            {subtitle && <p className="mt-0.5 text-xs text-muted-foreground">{subtitle}</p>}
          </div>
          <button onClick={onClose} aria-label="Fechar" className="rounded-sm p-1 text-muted-foreground hover:bg-muted">
            <X className="size-4" />
          </button>
        </header>
        <div className="flex-1 overflow-y-auto px-5 py-4">{children}</div>
        {footer && <footer className="flex justify-end gap-2 border-t bg-muted/50 px-5 py-3">{footer}</footer>}
      </aside>
    </div>
  );
}

export function Confirm({ open, title, description, confirmLabel, variant = "primary", loading, onConfirm, onCancel }: { open: boolean; title: string; description: ReactNode; confirmLabel: string; variant?: BtnVariant; loading?: boolean; onConfirm: () => void; onCancel: () => void }) {
  useEsc(open, onCancel);
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-foreground/40 animate-in fade-in" onClick={onCancel} />
      <div role="alertdialog" aria-modal="true" className="relative w-full max-w-md rounded-lg border bg-card animate-in zoom-in-95 duration-150">
        <div className="px-5 pt-5 pb-4">
          <h3 className="text-base font-semibold">{title}</h3>
          <div className="mt-2 text-sm text-muted-foreground">{description}</div>
        </div>
        <div className="flex justify-end gap-2 border-t bg-muted/50 px-5 py-3">
          <Button variant="secondary" onClick={onCancel} disabled={loading}>Cancelar</Button>
          <Button variant={variant} onClick={onConfirm} loading={loading}>{confirmLabel}</Button>
        </div>
      </div>
    </div>
  );
}

/* States */
export function EmptyState({ icon, title, description, action }: { icon: ReactNode; title: string; description: string; action?: ReactNode }) {
  return (
    <div className="flex flex-col items-center px-6 py-14 text-center">
      <div className="mb-3 flex size-10 items-center justify-center rounded-md border bg-muted text-muted-foreground">{icon}</div>
      <p className="text-sm font-semibold">{title}</p>
      <p className="mt-1 max-w-sm text-sm text-muted-foreground">{description}</p>
      {action && <div className="mt-4">{action}</div>}
    </div>
  );
}

export function TableSkeleton({ rows = 6, cols = 5 }: { rows?: number; cols?: number }) {
  return (
    <div className="divide-y" aria-busy="true" aria-label="Carregando">
      {Array.from({ length: rows }).map((_, i) => (
        <div key={i} className="flex gap-4 px-4 py-3.5">
          {Array.from({ length: cols }).map((_, j) => (
            <div key={j} className="h-3 flex-1 animate-pulse rounded-sm bg-muted" style={{ maxWidth: j === 0 ? 220 : 120 }} />
          ))}
        </div>
      ))}
    </div>
  );
}

export function PageHeader({ title, description, actions }: { title: string; description?: string; actions?: ReactNode }) {
  return (
    <div className="mb-5 flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
      <div>
        <h1 className="text-xl font-semibold tracking-tight">{title}</h1>
        {description && <p className="mt-0.5 text-sm text-muted-foreground">{description}</p>}
      </div>
      {actions && <div className="flex gap-2">{actions}</div>}
    </div>
  );
}

export function DetailRow({ label, children }: { label: string; children: ReactNode }) {
  return (
    <div className="grid grid-cols-3 gap-3 border-b py-2.5 text-sm last:border-0">
      <dt className="text-muted-foreground">{label}</dt>
      <dd className="col-span-2 font-medium">{children}</dd>
    </div>
  );
}

export const th = "px-4 py-2.5 text-left text-[11px] font-semibold uppercase tracking-wider text-muted-foreground";
export const td = "px-4 py-3 align-middle";
