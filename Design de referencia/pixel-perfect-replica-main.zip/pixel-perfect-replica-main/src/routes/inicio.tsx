import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, Building2, ClipboardCheck, Plus, Target, Users } from "lucide-react";
import { AppShell } from "@/components/app-shell";
import { Badge, Confianca, PageHeader, td, th } from "@/components/ls";
import { formatarData, useStore } from "@/lib/store";

export const Route = createFileRoute("/inicio")({
  head: () => ({
    meta: [
      { title: "Início — LeadScopeB2B" },
      { name: "description", content: "Resumo de empresas, pessoas e leads pendentes de revisão." },
      { property: "og:title", content: "Início — LeadScopeB2B" },
      { property: "og:description", content: "Resumo operacional do LeadScopeB2B." },
    ],
  }),
  component: () => (
    <AppShell>
      <Inicio />
    </AppShell>
  ),
});

function Inicio() {
  const { usuario, empresas, leads } = useStore();
  const pendentes = leads.filter((l) => l.status === "Em análise").sort((a, b) => b.criadoEm.localeCompare(a.criadoEm));
  const pessoas = new Set(leads.map((l) => l.email)).size;
  const hora = new Date().getHours();
  const saudacao = hora < 12 ? "Bom dia" : hora < 18 ? "Boa tarde" : "Boa noite";

  const indicadores = [
    { label: "Empresas", valor: empresas.length, det: `${empresas.filter((e) => e.status === "Ativa").length} ativas · ${empresas.filter((e) => e.status === "Em verificação").length} em verificação`, icon: Building2 },
    { label: "Pessoas", valor: pessoas, det: "Contatos vinculados a empresas", icon: Users },
    { label: "Leads", valor: leads.length, det: `${leads.filter((l) => l.status === "Qualificado").length} qualificados · ${leads.filter((l) => l.status === "Rejeitado").length} rejeitados`, icon: Target },
    { label: "Pendentes de revisão", valor: pendentes.length, det: "Aguardando decisão", icon: ClipboardCheck, destaque: true },
  ];

  return (
    <>
      <PageHeader title={`${saudacao}, ${usuario!.nome.split(" ")[0]}`} description={`Perfil ${usuario!.perfil} · ${new Date().toLocaleDateString("pt-BR", { weekday: "long", day: "numeric", month: "long" })}`} />

      <div className="grid grid-cols-2 gap-px overflow-hidden rounded-lg border bg-border lg:grid-cols-4">
        {indicadores.map((i) => (
          <div key={i.label} className="bg-card p-4">
            <div className="flex items-center justify-between text-xs font-medium text-muted-foreground">
              {i.label}
              <i.icon className={i.destaque ? "size-4 text-warning" : "size-4"} />
            </div>
            <p className="tabular mt-2 font-mono text-2xl font-semibold">{i.valor}</p>
            <p className="mt-1 text-xs text-muted-foreground">{i.det}</p>
          </div>
        ))}
      </div>

      <div className="mt-6 grid gap-6 lg:grid-cols-[1fr_280px]">
        <section className="overflow-hidden rounded-lg border bg-card">
          <header className="flex items-center justify-between border-b px-4 py-3">
            <div>
              <h2 className="text-sm font-semibold">Leads pendentes de revisão</h2>
              <p className="text-xs text-muted-foreground">Mais recentes primeiro</p>
            </div>
            <Link to="/leads" search={{ status: "Em análise" }} className="inline-flex items-center gap-1 text-xs font-medium text-primary hover:underline">
              Ver todos <ArrowRight className="size-3.5" />
            </Link>
          </header>
          {pendentes.length === 0 ? (
            <p className="px-4 py-10 text-center text-sm text-muted-foreground">Nenhum lead aguardando revisão.</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="border-b bg-muted/50">
                  <tr><th className={th}>Pessoa</th><th className={th}>Empresa</th><th className={th}>Confiança</th><th className={th}>Entrada</th><th className={th}></th></tr>
                </thead>
                <tbody className="divide-y">
                  {pendentes.slice(0, 5).map((l) => (
                    <tr key={l.id} className="hover:bg-muted/40">
                      <td className={td}><p className="font-medium">{l.pessoa}</p><p className="text-xs text-muted-foreground">{l.cargo}</p></td>
                      <td className={td}>{empresas.find((e) => e.id === l.empresaId)?.nomeFantasia}</td>
                      <td className={td}><Confianca valor={l.confianca} /></td>
                      <td className={`${td} tabular font-mono text-xs text-muted-foreground`}>{formatarData(l.criadoEm)}</td>
                      <td className={`${td} text-right`}>
                        <Link to="/leads" search={{ revisar: l.id }} className="text-xs font-medium text-primary hover:underline">Revisar</Link>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </section>

        <aside className="space-y-6">
          <section className="rounded-lg border bg-card">
            <h2 className="border-b px-4 py-3 text-sm font-semibold">Atalhos</h2>
            <div className="p-2">
              {[
                { to: "/empresas", search: { novo: true }, label: "Cadastrar empresa", icon: Plus },
                { to: "/empresas", search: {}, label: "Pesquisar empresas", icon: Building2 },
                { to: "/leads", search: { status: "Em análise" }, label: "Revisar leads", icon: ClipboardCheck },
              ].map((a) => (
                <Link key={a.label} to={a.to} search={a.search as never} className="flex items-center gap-2.5 rounded-md px-2.5 py-2 text-sm hover:bg-muted">
                  <span className="flex size-7 items-center justify-center rounded-md border bg-muted text-primary"><a.icon className="size-3.5" /></span>
                  {a.label}
                  <ArrowRight className="ml-auto size-3.5 text-muted-foreground" />
                </Link>
              ))}
            </div>
          </section>
          <section className="rounded-lg border bg-card p-4">
            <h2 className="text-sm font-semibold">Status dos leads</h2>
            <div className="mt-3 space-y-2">
              {(["Em análise", "Qualificado", "Rejeitado"] as const).map((s) => (
                <div key={s} className="flex items-center justify-between text-sm">
                  <Badge tone={s === "Em análise" ? "warning" : s === "Qualificado" ? "success" : "danger"}>{s}</Badge>
                  <span className="tabular font-mono">{leads.filter((l) => l.status === s).length}</span>
                </div>
              ))}
            </div>
          </section>
        </aside>
      </div>
    </>
  );
}
