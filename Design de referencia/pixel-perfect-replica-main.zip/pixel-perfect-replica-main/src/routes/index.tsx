import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState, type FormEvent } from "react";
import { AlertCircle, ArrowLeft, CheckCircle2, Eye, EyeOff } from "lucide-react";
import { Logo } from "@/components/app-shell";
import { Button, Field, Input } from "@/components/ls";
import { useStore, type Perfil } from "@/lib/store";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Entrar — LeadScopeB2B" },
      { name: "description", content: "Acesse o LeadScopeB2B para gerenciar e qualificar leads comerciais B2B." },
      { property: "og:title", content: "Entrar — LeadScopeB2B" },
      { property: "og:description", content: "Gerenciamento e qualificação de leads comerciais B2B." },
    ],
  }),
  component: Login,
});

const contas: Record<string, { nome: string; perfil: Perfil }> = {
  "usuario@leadscope.exemplo": { nome: "Bruno Carvalho", perfil: "Usuário" },
  "revisor@leadscope.exemplo": { nome: "Paula Rezende", perfil: "Revisor" },
  "admin@leadscope.exemplo": { nome: "Helena Moraes", perfil: "Administrador" },
};
const SENHA = "demo1234";

function Login() {
  const { entrar } = useStore();
  const navigate = useNavigate();
  const [modo, setModo] = useState<"login" | "recuperar" | "enviado">("login");
  const [email, setEmail] = useState("");
  const [senha, setSenha] = useState("");
  const [ver, setVer] = useState(false);
  const [erros, setErros] = useState<{ email?: string; senha?: string }>({});
  const [falha, setFalha] = useState("");
  const [carregando, setCarregando] = useState(false);

  const validarEmail = (v: string) => (!v ? "Informe o e-mail." : !/^\S+@\S+\.\S+$/.test(v) ? "E-mail em formato inválido." : undefined);

  const submit = (e: FormEvent) => {
    e.preventDefault();
    setFalha("");
    const er = { email: validarEmail(email), senha: modo === "login" && !senha ? "Informe a senha." : undefined };
    setErros(er);
    if (er.email || er.senha) return;
    setCarregando(true);
    setTimeout(() => {
      setCarregando(false);
      if (modo === "recuperar") return setModo("enviado");
      const c = contas[email.toLowerCase()];
      if (!c || senha !== SENHA) return setFalha("E-mail ou senha incorretos. Verifique os dados e tente novamente.");
      entrar({ ...c, email });
      navigate({ to: "/inicio" });
    }, 700);
  };

  return (
    <div className="grid min-h-screen lg:grid-cols-[1fr_480px]">
      <section className="relative hidden flex-col justify-between overflow-hidden bg-sidebar p-10 text-sidebar-foreground lg:flex">
        <Logo inverted />
        <div className="relative z-10 max-w-md">
          <p className="font-mono text-xs uppercase tracking-widest text-signal">Qualificação de leads B2B</p>
          <h1 className="mt-3 text-3xl font-semibold leading-tight tracking-tight">Empresas, pessoas e leads organizados em um só lugar.</h1>
          <p className="mt-3 text-sm text-sidebar-muted">Cadastre, pesquise por CNPJ ou CNAE, revise e qualifique contatos comerciais com rastreabilidade completa.</p>
        </div>
        <dl className="relative z-10 grid max-w-md grid-cols-3 gap-px overflow-hidden rounded-md border border-sidebar-border bg-sidebar-border text-sm">
          {[["Empresas", "Cadastro e CNAE"], ["Leads", "Revisão e status"], ["Auditoria", "Histórico de ações"]].map(([a, b]) => (
            <div key={a} className="bg-sidebar p-3">
              <dt className="font-medium">{a}</dt>
              <dd className="mt-0.5 text-xs text-sidebar-muted">{b}</dd>
            </div>
          ))}
        </dl>
        <svg className="absolute -right-24 top-1/2 size-[520px] -translate-y-1/2 text-sidebar-border" viewBox="0 0 200 200" fill="none" aria-hidden>
          {[90, 70, 50, 30].map((r) => <circle key={r} cx="100" cy="100" r={r} stroke="currentColor" />)}
          <line x1="100" y1="0" x2="100" y2="200" stroke="currentColor" />
          <line x1="0" y1="100" x2="200" y2="100" stroke="currentColor" />
          <circle cx="138" cy="68" r="3" className="fill-signal" />
        </svg>
      </section>

      <section className="flex items-center justify-center bg-card px-6 py-10">
        <div className="w-full max-w-sm">
          <div className="mb-8 lg:hidden"><Logo /></div>

          {modo === "enviado" ? (
            <div>
              <CheckCircle2 className="size-8 text-success" />
              <h2 className="mt-3 text-xl font-semibold">Verifique seu e-mail</h2>
              <p className="mt-1.5 text-sm text-muted-foreground">Se <strong className="text-foreground">{email}</strong> estiver cadastrado, você receberá as instruções para redefinir a senha.</p>
              <Button variant="secondary" className="mt-6 w-full" onClick={() => { setModo("login"); setSenha(""); }}>
                <ArrowLeft className="size-4" /> Voltar para o login
              </Button>
            </div>
          ) : (
            <form onSubmit={submit} noValidate>
              <h2 className="text-xl font-semibold tracking-tight">{modo === "login" ? "Entrar" : "Recuperar senha"}</h2>
              <p className="mt-1 text-sm text-muted-foreground">
                {modo === "login" ? "Acesse com suas credenciais corporativas." : "Informe o e-mail cadastrado para receber o link de redefinição."}
              </p>

              {falha && (
                <div role="alert" className="mt-5 flex gap-2 rounded-md border border-destructive/30 bg-danger-soft p-3 text-sm text-destructive">
                  <AlertCircle className="mt-0.5 size-4 shrink-0" />
                  {falha}
                </div>
              )}

              <div className="mt-5 space-y-4">
                <Field label="E-mail" error={erros.email}>
                  <Input type="email" autoComplete="email" placeholder="nome@empresa.com.br" value={email} invalid={!!erros.email} onChange={(e) => setEmail(e.target.value)} />
                </Field>
                {modo === "login" && (
                  <Field label="Senha" error={erros.senha}>
                    <div className="relative">
                      <Input type={ver ? "text" : "password"} autoComplete="current-password" value={senha} invalid={!!erros.senha} onChange={(e) => setSenha(e.target.value)} className="pr-9" />
                      <button type="button" onClick={() => setVer(!ver)} className="absolute inset-y-0 right-0 px-2.5 text-muted-foreground hover:text-foreground" aria-label={ver ? "Ocultar senha" : "Mostrar senha"}>
                        {ver ? <EyeOff className="size-4" /> : <Eye className="size-4" />}
                      </button>
                    </div>
                  </Field>
                )}
              </div>

              {modo === "login" && (
                <div className="mt-2 text-right">
                  <button type="button" onClick={() => { setModo("recuperar"); setErros({}); setFalha(""); }} className="text-xs font-medium text-primary hover:underline">
                    Esqueci minha senha
                  </button>
                </div>
              )}

              <Button type="submit" className="mt-5 w-full" loading={carregando}>
                {modo === "login" ? "Entrar" : "Enviar link"}
              </Button>
              {modo === "recuperar" && (
                <Button type="button" variant="ghost" className="mt-2 w-full" onClick={() => { setModo("login"); setErros({}); }}>
                  <ArrowLeft className="size-4" /> Voltar
                </Button>
              )}

              {modo === "login" && (
                <div className="mt-8 rounded-md border border-dashed bg-muted/60 p-3 text-xs">
                  <p className="font-semibold">Contas de demonstração · senha <span className="font-mono">{SENHA}</span></p>
                  <div className="mt-2 space-y-1">
                    {Object.entries(contas).map(([e, c]) => (
                      <button key={e} type="button" onClick={() => { setEmail(e); setSenha(SENHA); setErros({}); setFalha(""); }} className="flex w-full justify-between rounded-sm px-1.5 py-1 text-left hover:bg-card">
                        <span className="font-mono text-muted-foreground">{e}</span>
                        <span className="font-medium">{c.perfil}</span>
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </form>
          )}
        </div>
      </section>
    </div>
  );
}
