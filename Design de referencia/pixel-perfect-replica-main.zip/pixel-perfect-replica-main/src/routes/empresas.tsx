import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useMemo, useState, type FormEvent } from "react";
import { Building2, Eye, Plus, Search, SearchX } from "lucide-react";
import { toast } from "sonner";
import { AppShell } from "@/components/app-shell";
import { Badge, Button, Confirm, DetailRow, EmptyState, Field, Input, PageHeader, Panel, Select, TableSkeleton, td, th, toneStatus } from "@/components/ls";
import { CNAES, formatarData, mascaraCnpj, mascaraTelefone, useStore, validarCnpj, type Empresa } from "@/lib/store";

export const Route = createFileRoute("/empresas")({
  validateSearch: (s: Record<string, unknown>) => ({ novo: s.novo === true || s.novo === "true" ? true : undefined }),
  head: () => ({
    meta: [
      { title: "Empresas — LeadScopeB2B" },
      { name: "description", content: "Consulte e cadastre empresas por nome, CNPJ, status e CNAE." },
      { property: "og:title", content: "Empresas — LeadScopeB2B" },
      { property: "og:description", content: "Consulta e cadastro de empresas B2B." },
    ],
  }),
  component: () => (
    <AppShell>
      <Empresas />
    </AppShell>
  ),
});

const UFS = "AC AL AP AM BA CE DF ES GO MA MT MS MG PA PB PR PE PI RJ RN RS RO RR SC SP SE TO".split(" ");
const SEGMENTOS = ["Tecnologia", "Logística", "Alimentos", "Serviços", "Saúde", "Indústria", "Varejo", "Educação"];
const PORTES = ["Microempresa", "Pequeno", "Médio", "Grande"];

function Empresas() {
  const { empresas, adicionarEmpresa, leads } = useStore();
  const { novo } = Route.useSearch();
  const navigate = useNavigate();
  const [busca, setBusca] = useState("");
  const [status, setStatus] = useState("");
  const [cnae, setCnae] = useState("");
  const [carregando, setCarregando] = useState(true);
  const [form, setForm] = useState(!!novo);
  const [detalhe, setDetalhe] = useState<Empresa | null>(null);

  useEffect(() => {
    const t = setTimeout(() => setCarregando(false), 500);
    return () => clearTimeout(t);
  }, []);
  useEffect(() => {
    if (novo) {
      setForm(true);
      navigate({ to: "/empresas", search: {}, replace: true });
    }
  }, [novo, navigate]);

  const filtradas = useMemo(() => {
    const q = busca.trim().toLowerCase();
    const qd = q.replace(/\D/g, "");
    return empresas.filter(
      (e) =>
        (!q || e.razaoSocial.toLowerCase().includes(q) || e.nomeFantasia.toLowerCase().includes(q) || (qd.length > 0 && e.cnpj.replace(/\D/g, "").includes(qd))) &&
        (!status || e.status === status) &&
        (!cnae || e.cnae === cnae),
    );
  }, [empresas, busca, status, cnae]);

  const filtrosAtivos = busca || status || cnae;
  const limpar = () => { setBusca(""); setStatus(""); setCnae(""); };

  return (
    <>
      <PageHeader
        title="Empresas"
        description="Consulte empresas cadastradas por nome, CNPJ, status e CNAE."
        actions={<Button onClick={() => setForm(true)}><Plus className="size-4" /> Cadastrar empresa</Button>}
      />

      <div className="overflow-hidden rounded-lg border bg-card">
        <div className="grid gap-2 border-b p-3 md:grid-cols-[1fr_180px_260px_auto]">
          <div className="relative">
            <Search className="pointer-events-none absolute left-2.5 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
            <Input placeholder="Pesquisar por nome ou CNPJ" value={busca} onChange={(e) => setBusca(e.target.value)} className="pl-8" aria-label="Pesquisar" />
          </div>
          <Select value={status} onChange={(e) => setStatus(e.target.value)} aria-label="Status">
            <option value="">Todos os status</option>
            <option>Ativa</option><option>Em verificação</option><option>Inativa</option>
          </Select>
          <Select value={cnae} onChange={(e) => setCnae(e.target.value)} aria-label="CNAE">
            <option value="">Todos os CNAEs</option>
            {CNAES.map((c) => <option key={c.codigo} value={c.codigo}>{c.codigo} · {c.descricao}</option>)}
          </Select>
          <Button variant="ghost" onClick={limpar} disabled={!filtrosAtivos}>Limpar</Button>
        </div>

        {carregando ? (
          <TableSkeleton cols={6} />
        ) : empresas.length === 0 ? (
          <EmptyState icon={<Building2 className="size-5" />} title="Nenhuma empresa cadastrada" description="Cadastre a primeira empresa para começar a vincular pessoas e formar leads." action={<Button onClick={() => setForm(true)}><Plus className="size-4" /> Cadastrar empresa</Button>} />
        ) : filtradas.length === 0 ? (
          <EmptyState icon={<SearchX className="size-5" />} title="Nenhum resultado encontrado" description="Nenhuma empresa corresponde aos filtros aplicados. Revise os termos ou limpe os filtros." action={<Button variant="secondary" onClick={limpar}>Limpar filtros</Button>} />
        ) : (
          <>
            <div className="overflow-x-auto">
              <table className="w-full min-w-[820px] text-sm">
                <thead className="border-b bg-muted/50">
                  <tr><th className={th}>Empresa</th><th className={th}>CNPJ</th><th className={th}>CNAE</th><th className={th}>Localização</th><th className={th}>Status</th><th className={th}><span className="sr-only">Ações</span></th></tr>
                </thead>
                <tbody className="divide-y">
                  {filtradas.map((e) => (
                    <tr key={e.id} className="cursor-pointer hover:bg-muted/40" onClick={() => setDetalhe(e)}>
                      <td className={td}><p className="font-medium">{e.nomeFantasia}</p><p className="text-xs text-muted-foreground">{e.razaoSocial}</p></td>
                      <td className={`${td} tabular font-mono text-xs`}>{e.cnpj}</td>
                      <td className={td}><span className="font-mono text-xs">{e.cnae}</span><p className="max-w-[200px] truncate text-xs text-muted-foreground">{CNAES.find((c) => c.codigo === e.cnae)?.descricao}</p></td>
                      <td className={td}>{e.cidade}/{e.uf}</td>
                      <td className={td}><Badge tone={toneStatus(e.status)}>{e.status}</Badge></td>
                      <td className={`${td} text-right`}>
                        <Button size="sm" variant="secondary" onClick={(ev) => { ev.stopPropagation(); setDetalhe(e); }}><Eye className="size-3.5" /> Detalhes</Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <div className="border-t px-4 py-2.5 text-xs text-muted-foreground">
              Exibindo <span className="tabular font-mono text-foreground">{filtradas.length}</span> de <span className="tabular font-mono">{empresas.length}</span> empresas
            </div>
          </>
        )}
      </div>

      <Panel open={!!detalhe} onClose={() => setDetalhe(null)} title={detalhe?.nomeFantasia ?? ""} subtitle={detalhe?.razaoSocial}>
        {detalhe && (
          <>
            <div className="mb-4 flex items-center gap-2"><Badge tone={toneStatus(detalhe.status)}>{detalhe.status}</Badge><span className="text-xs text-muted-foreground">Cadastrada em {formatarData(detalhe.criadoEm)}</span></div>
            <dl>
              <DetailRow label="CNPJ"><span className="font-mono">{detalhe.cnpj}</span></DetailRow>
              <DetailRow label="CNAE"><span className="font-mono">{detalhe.cnae}</span> <span className="font-normal text-muted-foreground">· {CNAES.find((c) => c.codigo === detalhe.cnae)?.descricao}</span></DetailRow>
              <DetailRow label="Segmento">{detalhe.segmento}</DetailRow>
              <DetailRow label="Porte">{detalhe.porte}</DetailRow>
              <DetailRow label="Cidade/UF">{detalhe.cidade}/{detalhe.uf}</DetailRow>
              <DetailRow label="E-mail">{detalhe.email}</DetailRow>
              <DetailRow label="Telefone"><span className="font-mono">{detalhe.telefone}</span></DetailRow>
            </dl>
            <h3 className="mt-6 mb-2 text-xs font-semibold uppercase tracking-wider text-muted-foreground">Leads vinculados</h3>
            {leads.filter((l) => l.empresaId === detalhe.id).length === 0 ? (
              <p className="rounded-md border border-dashed p-4 text-center text-sm text-muted-foreground">Nenhum lead vinculado a esta empresa.</p>
            ) : (
              <ul className="divide-y rounded-md border">
                {leads.filter((l) => l.empresaId === detalhe.id).map((l) => (
                  <li key={l.id} className="flex items-center justify-between px-3 py-2.5 text-sm">
                    <div><p className="font-medium">{l.pessoa}</p><p className="text-xs text-muted-foreground">{l.cargo}</p></div>
                    <Badge tone={toneStatus(l.status)}>{l.status}</Badge>
                  </li>
                ))}
              </ul>
            )}
          </>
        )}
      </Panel>

      <FormEmpresa
        open={form}
        onClose={() => setForm(false)}
        cnpjsExistentes={empresas.map((e) => e.cnpj)}
        onSalvar={(dados) => {
          const nova = adicionarEmpresa(dados);
          setForm(false);
          limpar();
          toast.success("Empresa cadastrada", { description: `${nova.nomeFantasia} foi adicionada com status "Em verificação".` });
        }}
      />
    </>
  );
}

type Dados = Omit<Empresa, "id" | "criadoEm" | "status">;
const vazio: Dados = { razaoSocial: "", nomeFantasia: "", cnpj: "", segmento: "", porte: "", cidade: "", uf: "", email: "", telefone: "", cnae: "" };

function FormEmpresa({ open, onClose, onSalvar, cnpjsExistentes }: { open: boolean; onClose: () => void; onSalvar: (d: Dados) => void; cnpjsExistentes: string[] }) {
  const [d, setD] = useState<Dados>(vazio);
  const [erros, setErros] = useState<Partial<Record<keyof Dados, string>>>({});
  const [salvando, setSalvando] = useState(false);
  const [confirmarSaida, setConfirmarSaida] = useState(false);

  useEffect(() => { if (open) { setD(vazio); setErros({}); } }, [open]);

  const set = (k: keyof Dados, v: string) => { setD((x) => ({ ...x, [k]: v })); if (erros[k]) setErros((e) => ({ ...e, [k]: undefined })); };
  const sujo = Object.values(d).some(Boolean);
  const fechar = () => (sujo ? setConfirmarSaida(true) : onClose());

  const validar = () => {
    const e: typeof erros = {};
    if (d.razaoSocial.trim().length < 3) e.razaoSocial = "Informe a razão social (mín. 3 caracteres).";
    if (!d.nomeFantasia.trim()) e.nomeFantasia = "Informe o nome fantasia.";
    if (!validarCnpj(d.cnpj)) e.cnpj = "CNPJ incompleto. Use o formato 00.000.000/0000-00.";
    else if (cnpjsExistentes.includes(d.cnpj)) e.cnpj = "Já existe uma empresa com este CNPJ.";
    if (!d.segmento) e.segmento = "Selecione o segmento.";
    if (!d.porte) e.porte = "Selecione o porte.";
    if (!d.cidade.trim()) e.cidade = "Informe a cidade.";
    if (!d.uf) e.uf = "Selecione a UF.";
    if (!/^\S+@\S+\.\S+$/.test(d.email)) e.email = "Informe um e-mail válido.";
    if (d.telefone.replace(/\D/g, "").length < 10) e.telefone = "Telefone incompleto.";
    if (!d.cnae) e.cnae = "Selecione o CNAE principal.";
    setErros(e);
    return Object.keys(e).length === 0;
  };

  const submit = (ev: FormEvent) => {
    ev.preventDefault();
    if (!validar()) {
      toast.error("Revise os campos destacados", { description: "Alguns dados obrigatórios estão ausentes ou inválidos." });
      return;
    }
    setSalvando(true);
    setTimeout(() => { setSalvando(false); onSalvar(d); }, 800);
  };

  return (
    <>
      <Panel
        open={open}
        onClose={fechar}
        title="Cadastrar empresa"
        subtitle="Campos marcados com * são obrigatórios."
        footer={<><Button variant="secondary" onClick={fechar} disabled={salvando}>Cancelar</Button><Button type="submit" form="form-empresa" loading={salvando}>Salvar empresa</Button></>}
      >
        <form id="form-empresa" onSubmit={submit} noValidate className="space-y-5">
          <fieldset className="space-y-3">
            <legend className="mb-2 text-xs font-semibold uppercase tracking-wider text-muted-foreground">Identificação</legend>
            <Field label="Razão social" required error={erros.razaoSocial}><Input value={d.razaoSocial} invalid={!!erros.razaoSocial} onChange={(e) => set("razaoSocial", e.target.value)} placeholder="Ex.: Empresa Exemplo Ltda." /></Field>
            <div className="grid gap-3 sm:grid-cols-2">
              <Field label="Nome fantasia" required error={erros.nomeFantasia}><Input value={d.nomeFantasia} invalid={!!erros.nomeFantasia} onChange={(e) => set("nomeFantasia", e.target.value)} /></Field>
              <Field label="CNPJ" required error={erros.cnpj}><Input value={d.cnpj} invalid={!!erros.cnpj} onChange={(e) => set("cnpj", mascaraCnpj(e.target.value))} placeholder="00.000.000/0000-00" className="font-mono" inputMode="numeric" /></Field>
            </div>
            <Field label="CNAE principal" required error={erros.cnae}>
              <Select value={d.cnae} invalid={!!erros.cnae} onChange={(e) => set("cnae", e.target.value)}>
                <option value="">Selecione…</option>
                {CNAES.map((c) => <option key={c.codigo} value={c.codigo}>{c.codigo} · {c.descricao}</option>)}
              </Select>
            </Field>
            <div className="grid gap-3 sm:grid-cols-2">
              <Field label="Segmento" required error={erros.segmento}>
                <Select value={d.segmento} invalid={!!erros.segmento} onChange={(e) => set("segmento", e.target.value)}><option value="">Selecione…</option>{SEGMENTOS.map((s) => <option key={s}>{s}</option>)}</Select>
              </Field>
              <Field label="Porte" required error={erros.porte}>
                <Select value={d.porte} invalid={!!erros.porte} onChange={(e) => set("porte", e.target.value)}><option value="">Selecione…</option>{PORTES.map((s) => <option key={s}>{s}</option>)}</Select>
              </Field>
            </div>
          </fieldset>
          <fieldset className="space-y-3 border-t pt-4">
            <legend className="mb-2 pt-4 text-xs font-semibold uppercase tracking-wider text-muted-foreground">Localização e contato</legend>
            <div className="grid gap-3 sm:grid-cols-[1fr_110px]">
              <Field label="Cidade" required error={erros.cidade}><Input value={d.cidade} invalid={!!erros.cidade} onChange={(e) => set("cidade", e.target.value)} /></Field>
              <Field label="UF" required error={erros.uf}>
                <Select value={d.uf} invalid={!!erros.uf} onChange={(e) => set("uf", e.target.value)}><option value="">—</option>{UFS.map((u) => <option key={u}>{u}</option>)}</Select>
              </Field>
            </div>
            <div className="grid gap-3 sm:grid-cols-2">
              <Field label="E-mail" required error={erros.email}><Input type="email" value={d.email} invalid={!!erros.email} onChange={(e) => set("email", e.target.value)} placeholder="contato@empresa.com.br" /></Field>
              <Field label="Telefone" required error={erros.telefone}><Input value={d.telefone} invalid={!!erros.telefone} onChange={(e) => set("telefone", mascaraTelefone(e.target.value))} placeholder="(00) 0000-0000" className="font-mono" inputMode="tel" /></Field>
            </div>
          </fieldset>
        </form>
      </Panel>
      <Confirm
        open={confirmarSaida}
        title="Descartar cadastro?"
        description="Os dados preenchidos serão perdidos. Esta ação não pode ser desfeita."
        confirmLabel="Descartar"
        variant="danger"
        onCancel={() => setConfirmarSaida(false)}
        onConfirm={() => { setConfirmarSaida(false); onClose(); }}
      />
    </>
  );
}
