import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { CheckCircle2, Clock, Eye, Search, SearchX, ShieldAlert, Target, XCircle } from "lucide-react";
import { toast } from "sonner";
import { AppShell } from "@/components/app-shell";
import { Badge, Button, Confianca, Confirm, DetailRow, EmptyState, Field, Input, PageHeader, Panel, Select, TableSkeleton, Textarea, td, th, toneStatus } from "@/components/ls";
import { formatarData, useStore, type Lead, type StatusLead } from "@/lib/store";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/leads")({
  validateSearch: (s: Record<string, unknown>) => ({
    status: typeof s.status === "string" ? s.status : undefined,
    revisar: s.revisar ? Number(s.revisar) : undefined,
  }),
  head: () => ({
    meta: [
      { title: "Leads — LeadScopeB2B" },
      { name: "description", content: "Gerencie, revise e qualifique leads comerciais B2B." },
      { property: "og:title", content: "Leads — LeadScopeB2B" },
      { property: "og:description", content: "Gerenciamento e revisão de leads B2B." },
    ],
  }),
  component: () => (
    <AppShell>
      <Leads />
    </AppShell>
  ),
});

const ABAS = ["Todos", "Em análise", "Qualificado", "Rejeitado"] as const;

function Leads() {
  const { leads, empresas, usuario } = useStore();
  const search = Route.useSearch();
  const navigate = useNavigate();
  const [aba, setAba] = useState<string>(search.status && ABAS.includes(search.status as never) ? search.status : "Todos");
  const [busca, setBusca] = useState("");
  const [empresa, setEmpresa] = useState("");
  const [confianca, setConfianca] = useState("");
  const [carregando, setCarregando] = useState(true);
  const [detalheId, setDetalheId] = useState<number | null>(null);
  const [revisarId, setRevisarId] = useState<number | null>(null);
  const podeRevisar = usuario?.perfil !== "Usuário";

  useEffect(() => { const t = setTimeout(() => setCarregando(false), 500); return () => clearTimeout(t); }, []);
  useEffect(() => {
    if (search.revisar) { setRevisarId(search.revisar); navigate({ to: "/leads", search: {}, replace: true }); }
  }, [search.revisar, navigate]);

  const nomeEmpresa = (id: number) => empresas.find((e) => e.id === id)?.nomeFantasia ?? "—";
  const filtrados = useMemo(() => {
    const q = busca.trim().toLowerCase();
    return leads.filter((l) => {
      if (aba !== "Todos" && l.status !== aba) return false;
      if (empresa && l.empresaId !== Number(empresa)) return false;
      if (confianca === "alta" && l.confianca < 75) return false;
      if (confianca === "media" && (l.confianca < 50 || l.confianca >= 75)) return false;
      if (confianca === "baixa" && l.confianca >= 50) return false;
      return !q || l.pessoa.toLowerCase().includes(q) || l.cargo.toLowerCase().includes(q) || l.email.toLowerCase().includes(q);
    });
  }, [leads, aba, busca, empresa, confianca]);

  const limpar = () => { setBusca(""); setEmpresa(""); setConfianca(""); setAba("Todos"); };
  const detalhe = leads.find((l) => l.id === detalheId) ?? null;
  const revisando = leads.find((l) => l.id === revisarId) ?? null;

  return (
    <>
      <PageHeader title="Leads" description="Pessoas vinculadas a empresas, com status de qualificação e nível de confiança." />

      <div className="overflow-hidden rounded-lg border bg-card">
        <div className="flex gap-1 overflow-x-auto border-b px-3 pt-2" role="tablist">
          {ABAS.map((a) => {
            const n = a === "Todos" ? leads.length : leads.filter((l) => l.status === a).length;
            return (
              <button key={a} role="tab" aria-selected={aba === a} onClick={() => setAba(a)}
                className={cn("-mb-px flex items-center gap-1.5 whitespace-nowrap border-b-2 px-3 py-2 text-sm", aba === a ? "border-primary font-medium text-foreground" : "border-transparent text-muted-foreground hover:text-foreground")}>
                {a}<span className="tabular rounded-sm bg-muted px-1.5 font-mono text-[11px]">{n}</span>
              </button>
            );
          })}
        </div>
        <div className="grid gap-2 border-b p-3 md:grid-cols-[1fr_200px_180px_auto]">
          <div className="relative">
            <Search className="pointer-events-none absolute left-2.5 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
            <Input placeholder="Pesquisar por nome, cargo ou e-mail" value={busca} onChange={(e) => setBusca(e.target.value)} className="pl-8" aria-label="Pesquisar" />
          </div>
          <Select value={empresa} onChange={(e) => setEmpresa(e.target.value)} aria-label="Empresa">
            <option value="">Todas as empresas</option>
            {empresas.map((e) => <option key={e.id} value={e.id}>{e.nomeFantasia}</option>)}
          </Select>
          <Select value={confianca} onChange={(e) => setConfianca(e.target.value)} aria-label="Confiança">
            <option value="">Qualquer confiança</option>
            <option value="alta">Alta (≥ 75%)</option><option value="media">Média (50–74%)</option><option value="baixa">Baixa (&lt; 50%)</option>
          </Select>
          <Button variant="ghost" onClick={limpar}>Limpar</Button>
        </div>

        {carregando ? <TableSkeleton cols={6} /> : leads.length === 0 ? (
          <EmptyState icon={<Target className="size-5" />} title="Nenhum lead cadastrado" description="Leads surgem ao vincular pessoas a empresas cadastradas." />
        ) : filtrados.length === 0 ? (
          <EmptyState icon={<SearchX className="size-5" />} title="Nenhum lead encontrado" description="Não há leads que correspondam aos filtros selecionados." action={<Button variant="secondary" onClick={limpar}>Limpar filtros</Button>} />
        ) : (
          <>
            <div className="overflow-x-auto">
              <table className="w-full min-w-[860px] text-sm">
                <thead className="border-b bg-muted/50">
                  <tr><th className={th}>Pessoa</th><th className={th}>Empresa</th><th className={th}>Cargo</th><th className={th}>Status</th><th className={th}>Confiança</th><th className={th}><span className="sr-only">Ações</span></th></tr>
                </thead>
                <tbody className="divide-y">
                  {filtrados.map((l) => (
                    <tr key={l.id} className="hover:bg-muted/40">
                      <td className={td}><p className="font-medium">{l.pessoa}</p><p className="text-xs text-muted-foreground">{l.email}</p></td>
                      <td className={td}>{nomeEmpresa(l.empresaId)}</td>
                      <td className={td}>{l.cargo}</td>
                      <td className={td}><Badge tone={toneStatus(l.status)}>{l.status}</Badge></td>
                      <td className={td}><Confianca valor={l.confianca} /></td>
                      <td className={`${td} text-right`}>
                        <div className="flex justify-end gap-1.5">
                          <Button size="sm" variant="ghost" onClick={() => setDetalheId(l.id)}><Eye className="size-3.5" /> Detalhes</Button>
                          <Button size="sm" variant="secondary" onClick={() => setRevisarId(l.id)}>Revisar</Button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <div className="border-t px-4 py-2.5 text-xs text-muted-foreground">Exibindo <span className="tabular font-mono text-foreground">{filtrados.length}</span> de <span className="tabular font-mono">{leads.length}</span> leads</div>
          </>
        )}
      </div>

      <Panel open={!!detalhe} onClose={() => setDetalheId(null)} title={detalhe?.pessoa ?? ""} subtitle={detalhe ? `${detalhe.cargo} · ${nomeEmpresa(detalhe.empresaId)}` : ""}
        footer={detalhe && <Button onClick={() => { setRevisarId(detalhe.id); setDetalheId(null); }}>Revisar lead</Button>}>
        {detalhe && (
          <>
            <dl>
              <DetailRow label="Status"><Badge tone={toneStatus(detalhe.status)}>{detalhe.status}</Badge></DetailRow>
              <DetailRow label="Confiança"><Confianca valor={detalhe.confianca} /></DetailRow>
              <DetailRow label="E-mail">{detalhe.email}</DetailRow>
              <DetailRow label="Empresa">{nomeEmpresa(detalhe.empresaId)} <span className="font-mono text-xs font-normal text-muted-foreground">{empresas.find((e) => e.id === detalhe.empresaId)?.cnpj}</span></DetailRow>
              <DetailRow label="Origem">{detalhe.origem}</DetailRow>
              <DetailRow label="Entrada">{formatarData(detalhe.criadoEm)}</DetailRow>
            </dl>
            <Historico lead={detalhe} />
          </>
        )}
      </Panel>

      <Revisao lead={revisando} podeRevisar={podeRevisar} nomeEmpresa={revisando ? nomeEmpresa(revisando.empresaId) : ""} onClose={() => setRevisarId(null)} />
    </>
  );
}

function Historico({ lead }: { lead: Lead }) {
  return (
    <>
      <h3 className="mt-6 mb-3 text-xs font-semibold uppercase tracking-wider text-muted-foreground">Histórico</h3>
      <ol className="space-y-3 border-l pl-4">
        {[...lead.historico].reverse().map((h, i) => (
          <li key={i} className="relative text-sm">
            <span className="absolute -left-[21px] top-1.5 size-2 rounded-full border-2 border-card bg-primary" />
            <p><span className="font-medium">{h.acao}</span> <span className="text-muted-foreground">· {h.autor}</span></p>
            <p className="tabular font-mono text-xs text-muted-foreground">{formatarData(h.data)}</p>
            {h.comentario && <p className="mt-1 rounded-md bg-muted px-2.5 py-1.5 text-xs">“{h.comentario}”</p>}
          </li>
        ))}
      </ol>
    </>
  );
}

const DECISOES: { valor: StatusLead; label: string; desc: string; icon: typeof CheckCircle2; cor: string }[] = [
  { valor: "Qualificado", label: "Qualificar", desc: "Contato válido e com potencial comercial.", icon: CheckCircle2, cor: "text-success" },
  { valor: "Em análise", label: "Manter em análise", desc: "Faltam informações para decidir.", icon: Clock, cor: "text-warning" },
  { valor: "Rejeitado", label: "Rejeitar", desc: "Dados inválidos ou sem aderência.", icon: XCircle, cor: "text-destructive" },
];

function Revisao({ lead, podeRevisar, nomeEmpresa, onClose }: { lead: Lead | null; podeRevisar: boolean; nomeEmpresa: string; onClose: () => void }) {
  const { revisarLead } = useStore();
  const [decisao, setDecisao] = useState<StatusLead | "">("");
  const [comentario, setComentario] = useState("");
  const [erro, setErro] = useState<{ decisao?: string; comentario?: string }>({});
  const [confirmar, setConfirmar] = useState(false);
  const [salvando, setSalvando] = useState(false);

  useEffect(() => { setDecisao(""); setComentario(""); setErro({}); }, [lead?.id]);

  const prosseguir = () => {
    const e: typeof erro = {};
    if (!decisao) e.decisao = "Selecione uma decisão.";
    if (decisao === "Rejeitado" && comentario.trim().length < 10) e.comentario = "Justifique a rejeição (mín. 10 caracteres).";
    setErro(e);
    if (!e.decisao && !e.comentario) setConfirmar(true);
  };

  const executar = () => {
    if (!lead || !decisao) return;
    setSalvando(true);
    setTimeout(() => {
      revisarLead(lead.id, decisao, comentario.trim());
      setSalvando(false);
      setConfirmar(false);
      onClose();
      const msg = decisao === "Qualificado" ? "Lead qualificado" : decisao === "Rejeitado" ? "Lead rejeitado" : "Lead mantido em análise";
      (decisao === "Rejeitado" ? toast.warning : toast.success)(msg, { description: `${lead.pessoa} · ${nomeEmpresa}` });
    }, 700);
  };

  const sel = DECISOES.find((d) => d.valor === decisao);

  return (
    <>
      <Panel open={!!lead} onClose={onClose} title="Revisar lead" subtitle={lead ? `${lead.pessoa} · ${lead.cargo} · ${nomeEmpresa}` : ""} width="max-w-lg"
        footer={podeRevisar && <><Button variant="secondary" onClick={onClose}>Cancelar</Button><Button onClick={prosseguir}>Registrar revisão</Button></>}>
        {lead && (!podeRevisar ? (
          <div role="alert" className="flex gap-2.5 rounded-md border border-warning/30 bg-warning-soft p-3 text-sm">
            <ShieldAlert className="mt-0.5 size-4 shrink-0 text-warning" />
            <div><p className="font-medium">Permissão insuficiente</p><p className="mt-0.5 text-muted-foreground">Somente os perfis Revisor e Administrador podem revisar leads. Entre com outra conta de demonstração.</p></div>
          </div>
        ) : (
          <div className="space-y-5">
            <div className="flex items-center justify-between rounded-md border bg-muted/50 px-3 py-2.5 text-sm">
              <span className="text-muted-foreground">Situação atual</span>
              <div className="flex items-center gap-3"><Badge tone={toneStatus(lead.status)}>{lead.status}</Badge><Confianca valor={lead.confianca} /></div>
            </div>
            <fieldset>
              <legend className="mb-2 text-xs font-medium">Decisão <span className="text-destructive">*</span></legend>
              <div className="space-y-2">
                {DECISOES.map((d) => (
                  <label key={d.valor} className={cn("flex cursor-pointer items-start gap-3 rounded-md border p-3 transition-colors", decisao === d.valor ? "border-primary bg-accent" : "hover:bg-muted/60", erro.decisao && "border-destructive/50")}>
                    <input type="radio" name="decisao" className="mt-1 accent-primary" checked={decisao === d.valor} onChange={() => { setDecisao(d.valor); setErro({}); }} />
                    <d.icon className={cn("mt-0.5 size-4 shrink-0", d.cor)} />
                    <span><span className="block text-sm font-medium">{d.label}</span><span className="block text-xs text-muted-foreground">{d.desc}</span></span>
                  </label>
                ))}
              </div>
              {erro.decisao && <p className="mt-1 text-xs text-destructive">{erro.decisao}</p>}
            </fieldset>
            <Field label="Comentário" required={decisao === "Rejeitado"} error={erro.comentario} hint={`${comentario.length}/500 · registrado no histórico do lead`}>
              <Textarea rows={4} maxLength={500} value={comentario} onChange={(e) => { setComentario(e.target.value); setErro((x) => ({ ...x, comentario: undefined })); }} placeholder="Descreva o motivo da decisão…" className={erro.comentario ? "border-destructive" : ""} />
            </Field>
            <Historico lead={lead} />
          </div>
        ))}
      </Panel>
      <Confirm
        open={confirmar}
        title={`Confirmar: ${sel?.label.toLowerCase()}?`}
        description={<>O lead <strong className="text-foreground">{lead?.pessoa}</strong> passará para o status <strong className="text-foreground">{decisao}</strong>. A decisão será registrada no histórico com seu nome.</>}
        confirmLabel="Confirmar revisão"
        variant={decisao === "Rejeitado" ? "danger" : decisao === "Qualificado" ? "success" : "primary"}
        loading={salvando}
        onCancel={() => setConfirmar(false)}
        onConfirm={executar}
      />
    </>
  );
}
